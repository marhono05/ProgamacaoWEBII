package com.example.demo.controller;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.demo.entity.Imovel;
import com.example.demo.service.ImovelService;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
@RequestMapping("/imovel")
public class ImovelController {

    @Autowired
    private ImovelService service;

    // ✅ CRIAR (POST)
    @PostMapping
    public ResponseEntity<Imovel> createPost(@RequestBody Imovel imovel){
        Imovel imovelCadastrado = service.criar(imovel);
        return ResponseEntity.status(HttpStatus.CREATED).body(imovelCadastrado);
    }

    // ✅ LISTAR (GET)
    @GetMapping
    public List<Imovel> listarTodosImovels(){
        List<Imovel> imoveis = service.listar();
        return imoveis;
    }

    // ✅ BUSCAR POR ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity buscarPorId(@PathVariable(value = "id") Long id) {
        Imovel Imovel = service.buscarPorId(id);
        return ResponseEntity.ok(Imovel);
    }

    // ✅ ATUALIZAR (PUT)
    @PutMapping("/{id}")
    public ResponseEntity<Imovel> updatePost(@PathVariable(value = "id") Long id, @RequestBody Imovel imovel) {        
        imovel.setIdImovel(id);
        Imovel imovelAtualizado = service.atualizar(imovel);
        return ResponseEntity.ok(imovelAtualizado);
    }

    // ✅ DELETAR (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePost(@PathVariable(value = "id") Long id){
        boolean deleted = service.deletar(id);

        if (deleted) {
            return ResponseEntity.noContent().build();
        }else {
            return ResponseEntity.notFound().build();
        }
    }

}
