package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter

public class Comerciais extends Imovel{

    private long idComerciais;
    private int numSalas;
    private int numBanheiros;

}
