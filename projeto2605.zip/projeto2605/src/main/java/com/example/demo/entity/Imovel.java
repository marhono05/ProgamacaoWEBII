package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Inheritance(strategy = jakarta.persistence.InheritanceType.JOINED)
@Table(name="Imovel")
@Getter
@Setter

public class Imovel {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long idImovel;
    private double valor;
    private double areaTotal;
    private double areaConstruida;
    private String cidade;
    private String estado;
    private String cep;
    private double latitute;
    private double longitude;
   

}
