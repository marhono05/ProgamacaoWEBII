package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter

@Entity
public class Residenciais extends Imovel{
    
    private long idResidencias;    
    private int numQuartos;
    private int numSuites;
    private int numBanheiros;
    private int vagasGaragem;


}
