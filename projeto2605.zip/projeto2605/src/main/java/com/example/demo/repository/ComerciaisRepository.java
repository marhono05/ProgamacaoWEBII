package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Comerciais;
import com.example.demo.entity.Imovel;
import com.example.demo.entity.Residenciais;
import java.util.List;


public interface ComerciaisRepository extends JpaRepository<Comerciais, Long>{

    List<Comerciais> findByNumSalasGreaterThan(int quantidade);

}
