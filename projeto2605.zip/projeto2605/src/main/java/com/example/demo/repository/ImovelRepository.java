package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Imovel;

public interface ImovelRepository extends JpaRepository<Imovel, Long>{
    List<Imovel> findByValorBetween(double valorMin, double valorMax);
    List<Imovel> findByCidade(String cidade);
    



}
