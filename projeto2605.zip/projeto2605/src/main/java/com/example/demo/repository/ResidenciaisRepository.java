package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Imovel;
import com.example.demo.entity.Residenciais;
import java.util.List;


public interface ResidenciaisRepository extends JpaRepository<Residenciais, Long>{
    
    List<Residenciais> findByNumQuartosGreaterThan(int quantidade);

}
