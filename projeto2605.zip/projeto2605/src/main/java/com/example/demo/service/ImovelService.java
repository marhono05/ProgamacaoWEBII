package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Imovel;
import com.example.demo.repository.ImovelRepository;


@Service
public class ImovelService {
    private ImovelRepository repository;

    public ImovelService(ImovelRepository repository) {
        this.repository = repository;
    }

    public Imovel criar(Imovel request) {
        return repository.save(request);
    }

    public List<Imovel> listar() {
        return repository.findAll();
    }

    public Imovel buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Imovel não encontrado"));
    }

    
    public Imovel atualizar(Imovel request) {
        return repository.save(request);
    }

    public boolean deletar(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }

}
